const Vue = require('vue').default;
const Options = require('./Options.vue');

new Vue(Options).$mount('#options');
