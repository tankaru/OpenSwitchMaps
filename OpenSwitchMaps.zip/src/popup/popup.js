const Vue = require('vue').default;
const Popup = require('./Popup.vue');

new Vue(Popup).$mount('#popup');
